import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _47281364 = () => interopDefault(import('../pages/admin.vue' /* webpackChunkName: "pages/admin" */))
const _5b22999d = () => interopDefault(import('../pages/users.vue' /* webpackChunkName: "pages/users" */))
const _180ab660 = () => interopDefault(import('../pages/users/index.vue' /* webpackChunkName: "pages/users/index" */))
const _7eb685d4 = () => interopDefault(import('../pages/users/foo.vue' /* webpackChunkName: "pages/users/foo" */))
const _5d81975f = () => interopDefault(import('../pages/detail/abc.vue' /* webpackChunkName: "pages/detail/abc" */))
const _7cd8d9c3 = () => interopDefault(import('../pages/detail/foo.vue' /* webpackChunkName: "pages/detail/foo" */))
const _15b8bf67 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/abc/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/admin",
    component: _47281364,
    name: "admin"
  }, {
    path: "/users",
    component: _5b22999d,
    children: [{
      path: "",
      component: _180ab660,
      name: "users"
    }, {
      path: "foo",
      component: _7eb685d4,
      name: "users-foo"
    }]
  }, {
    path: "/detail/abc",
    component: _5d81975f,
    name: "detail-abc"
  }, {
    path: "/detail/foo",
    component: _7cd8d9c3,
    name: "detail-foo"
  }, {
    path: "/",
    component: _15b8bf67,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
